library(testthat)
library(comrad)

test_check("comrad")
